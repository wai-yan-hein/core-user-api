-- MariaDB dump 10.19  Distrib 10.10.4-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: cv_user_winmm
-- ------------------------------------------------------
-- Server version	10.10.4-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appuser`
--

DROP TABLE IF EXISTS `appuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appuser` (
  `user_code` varchar(15) NOT NULL,
  `role_code` varchar(15) DEFAULT NULL,
  `user_short_name` varchar(25) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `active` bit(1) NOT NULL DEFAULT b'0',
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `doctor_id` varchar(15) DEFAULT NULL,
  `updated_date` datetime NOT NULL DEFAULT current_timestamp(),
  `dept_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_code`),
  UNIQUE KEY `user_short_name_UNIQUE` (`user_short_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appuser`
--

LOCK TABLES `appuser` WRITE;
/*!40000 ALTER TABLE `appuser` DISABLE KEYS */;
INSERT INTO `appuser` VALUES
('1','1','admin','admin','',NULL,'admin',NULL,NULL,'2023-06-15 12:58:33',1);
/*!40000 ALTER TABLE `appuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_type`
--

DROP TABLE IF EXISTS `business_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_type` (
  `bus_id` int(11) NOT NULL,
  `bus_name` varchar(255) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`bus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_type`
--

LOCK TABLES `business_type` WRITE;
/*!40000 ALTER TABLE `business_type` DISABLE KEYS */;
INSERT INTO `business_type` VALUES
(1,'Trade','2023-06-27 11:20:12');
/*!40000 ALTER TABLE `business_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_info`
--

DROP TABLE IF EXISTS `company_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_info` (
  `comp_code` varchar(15) NOT NULL,
  `user_code` varchar(15) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `short_code` varchar(5) DEFAULT NULL,
  `security_code` varchar(255) DEFAULT NULL,
  `parent` varchar(15) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `active` bit(1) NOT NULL DEFAULT b'0',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `currency` varchar(15) NOT NULL,
  `created_by` varchar(15) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `bus_id` int(11) DEFAULT NULL,
  `batch_lock` bit(1) NOT NULL DEFAULT b'0',
  `year_end_date` date DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`comp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_info`
--

LOCK TABLES `company_info` WRITE;
/*!40000 ALTER TABLE `company_info` DISABLE KEYS */;
INSERT INTO `company_info` VALUES
('01','01','Aung Naing Thitsar','09 5105447.09 785105447. 09 965105447','',NULL,NULL,NULL,'အမှတ်တ/၆၃ မင်းရဲကျော်စွာလမ်း (၉)ရပ်ကွက် အရှေ့ဒဂုံ ရန်ကုန်မြို့','','2022-06-01','2029-05-29','MMK','1','2023-07-03 19:23:27',1,'\0',NULL,'2023-06-27 11:18:26');
/*!40000 ALTER TABLE `company_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `cur_code` varchar(15) NOT NULL,
  `cur_name` varchar(255) DEFAULT NULL,
  `cur_symbol` varchar(255) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `cur_gain_acc` varchar(15) DEFAULT NULL,
  `cur_lost_acc` varchar(15) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`cur_code`),
  UNIQUE KEY `cur_code` (`cur_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES
('MMK','MMK','MMK','',NULL,NULL,'2023-06-12 08:15:38'),
('USD','USD','USD','',NULL,NULL,'2023-06-17 08:01:36');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL,
  `user_code` varchar(15) NOT NULL,
  `dept_name` varchar(255) NOT NULL,
  `inv_queue` varchar(255) DEFAULT NULL,
  `acc_queue` varchar(255) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `active` bit(1) NOT NULL DEFAULT b'0',
  `deleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES
(1,'001','Head Office',NULL,NULL,'2023-08-04 07:59:51','','','','','\0');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exchange_rate`
--

DROP TABLE IF EXISTS `exchange_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange_rate` (
  `ex_code` varchar(15) NOT NULL,
  `comp_code` varchar(15) NOT NULL,
  `ex_date` timestamp NULL DEFAULT NULL,
  `home_factor` double DEFAULT NULL,
  `home_cur` varchar(15) DEFAULT NULL,
  `target_factor` double DEFAULT NULL,
  `target_cur` varchar(15) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` varchar(15) DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(15) DEFAULT NULL,
  `deleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ex_code`,`comp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange_rate`
--

LOCK TABLES `exchange_rate` WRITE;
/*!40000 ALTER TABLE `exchange_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `exchange_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mac_prop`
--

DROP TABLE IF EXISTS `mac_prop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mac_prop` (
  `mac_id` int(11) NOT NULL,
  `prop_key` varchar(255) NOT NULL,
  `prop_value` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`mac_id`,`prop_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mac_prop`
--

LOCK TABLES `mac_prop` WRITE;
/*!40000 ALTER TABLE `mac_prop` DISABLE KEYS */;
/*!40000 ALTER TABLE `mac_prop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `machine_info`
--

DROP TABLE IF EXISTS `machine_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `machine_info` (
  `mac_id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` varchar(255) NOT NULL,
  `mac_ip` varchar(225) DEFAULT NULL,
  `mac_name` varchar(225) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `pro_update` bit(1) NOT NULL DEFAULT b'0',
  `mac_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`mac_id`,`mac_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `machine_info`
--

LOCK TABLES `machine_info` WRITE;
/*!40000 ALTER TABLE `machine_info` DISABLE KEYS */;
INSERT INTO `machine_info` VALUES
(1,'L1HF9B80BJV','192.168.100.254','WAIGYI','2023-06-27 14:00:13','','4C:1D:96:13:96:BF');
/*!40000 ALTER TABLE `machine_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `menu_code` varchar(15) NOT NULL,
  `comp_code` varchar(15) NOT NULL,
  `user_code` varchar(15) DEFAULT NULL,
  `menu_class` varchar(150) DEFAULT NULL,
  `menu_name` varchar(50) DEFAULT NULL,
  `menu_name_mm` varchar(500) DEFAULT NULL,
  `menu_url` varchar(500) DEFAULT NULL,
  `parent_menu_code` varchar(50) NOT NULL,
  `menu_type` varchar(50) DEFAULT NULL,
  `account` varchar(15) DEFAULT NULL,
  `order_by` int(11) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`menu_code`,`comp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES
('01','01',NULL,'Inventory','Report',NULL,'','79','Menu',NULL,100,'2023-06-27 11:19:12'),
('012022-001','01',NULL,'Account','Account',NULL,'','1','Menu',NULL,3,'2023-07-03 19:18:11'),
('012022-002','01',NULL,'Account','Setup',NULL,'','012022-001','Menu','',3,'2023-06-27 11:19:12'),
('012022-003','01',NULL,'Account','Department',NULL,'','012022-002','Menu','',NULL,'2023-06-27 11:19:12'),
('012022-004','01',NULL,'AllCash','Cash Book',NULL,'','012022-001','Menu','',1,'2023-06-27 11:19:12'),
('012022-005','01',NULL,'Setup','COA Managment',NULL,'','012022-002','Menu','',NULL,'2023-06-27 11:19:12'),
('012022-007','01',NULL,'System','User Setup',NULL,'','50','Menu','',NULL,'2023-06-27 11:19:12'),
('012022-008','01',NULL,'Inventory','Sale By Stock (Summary)',NULL,'SaleByStockSummary','01','Report','',NULL,'2023-06-27 11:19:12'),
('012022-009','01',NULL,'Inventory','Opening Stock By Group',NULL,'OpeningByGroup','01','Report','',0,'2023-06-27 11:19:12'),
('012022-010','01',NULL,'Inventory','Opening Stock By Location',NULL,'OpeningByLocation','01','Report','',0,'2023-06-27 11:19:12'),
('012022-011','01',NULL,'Inventory','Sale By Customer (Summary)',NULL,'SaleByCustomerSummary','01','Report','',NULL,'2023-06-27 11:19:12'),
('012022-012','01',NULL,'Inventory','Purchase By Supplier (Summary)',NULL,'PurchaseBySupplierSummary','01','Report','',NULL,'2023-06-27 11:19:12'),
('012022-013','01',NULL,'Inventory','Purchase By Stock (Summary)',NULL,'PurchaseByStockSummary','01','Report','',NULL,'2023-06-27 11:19:12'),
('012022-014','01',NULL,'System','Company',NULL,'','50','Menu','',NULL,'2023-06-27 11:19:12'),
('012022-015','01',NULL,'Inventory','Stock In/Out (Summary)',NULL,'StockInOutSummary','01','Report','',NULL,'2023-06-27 11:19:12'),
('022022-001','01',NULL,'Inventory','Stock In/Out (Detail)',NULL,'StockInOutDetail','01','Report','',NULL,'2023-06-27 11:19:12'),
('0223-001','01',NULL,'AllCash','Bank',NULL,'','012022-001','Menu','',2,'2023-06-27 11:19:12'),
('0223-002','01',NULL,'DayBook','Day Book',NULL,'','012022-001','Menu','',3,'2023-06-27 11:19:12'),
('0223-003','01',NULL,'Account','Journal',NULL,'','012022-001','Menu','',4,'2023-06-27 11:19:12'),
('0223-004','01',NULL,'Account','Journal Voucher',NULL,'','0223-003','Menu','',1,'2023-06-27 11:19:12'),
('0223-005','01',NULL,'Account','Journal Stock Closing',NULL,'','0223-003','Menu','',2,'2023-06-27 11:19:12'),
('0223-006','01',NULL,'Account','Chart Of Account',NULL,'','012022-002','Menu','',0,'2023-06-27 11:19:12'),
('0223-007','01',NULL,'DayBook','အဝယ် စာရင်း',NULL,NULL,'0223-002','Menu','D-00051',NULL,'2023-06-27 11:19:12'),
('0223-008','01',NULL,'DayBook','အရောင်း စာရင်း',NULL,NULL,'0223-002','Menu','D-00060',NULL,'2023-06-27 11:19:12'),
('0223-009','01',NULL,'','AR / AP',NULL,'','052022-001','Menu','',1,'2023-06-27 11:19:12'),
('0223-010','01',NULL,'Account','Financial Report',NULL,'','052022-001','Menu','',3,'2023-06-27 11:19:12'),
('0223-011','01',NULL,'AllCash','Daily Cash',NULL,'','012022-004','Menu','600001',0,'2023-06-27 18:49:35'),
('0223-012','01',NULL,'AllCash','KBZ',NULL,'','0223-001','Menu','003-00001',0,'2023-06-27 18:51:22'),
('0223-013','01',NULL,'AllCash','AYA ',NULL,'','0223-001','Menu','003-00002',0,'2023-06-27 18:51:32'),
('0223-014','01',NULL,'Account','Trader',NULL,'','012022-002','Menu','',0,'2023-06-27 11:19:12'),
('0223-015','01',NULL,'Account','Credit Detail',NULL,'CreditDetail','0223-010','Report','',0,'2023-06-27 11:19:12'),
('0223-016','01',NULL,'Account','Income & Expenditure (Detail)',NULL,'Income&ExpenditureDetail','0223-010','Report','',0,'2023-06-27 11:19:12'),
('0223-017','01',NULL,'Account','Income & Expenditure (Summary)',NULL,'Income&ExpenditureSummary','0223-010','Report','',0,'2023-06-27 11:19:12'),
('0223-018','01',NULL,'Account','Profit & Loss (Detail)',NULL,'Profit&LossDetail','0223-010','Report','',0,'2023-06-27 11:19:12'),
('0223-019','01',NULL,'Account','Profit & Loss (Summary)',NULL,'Profit&LossSummary','0223-010','Report','',0,'2023-06-27 11:19:12'),
('0223-020','01',NULL,'Account','Balance Sheet (Detail)',NULL,'BalanceSheetDetail','0223-010','Report','',0,'2023-06-27 11:19:12'),
('0223-021','01',NULL,'Account','Balance Sheet (Summary)',NULL,'BalanceSheetSummary','0223-010','Report','',0,'2023-06-27 11:19:12'),
('0223-022','01',NULL,'Account','Individual Statement',NULL,'IndividualStatement','0223-010','Report','',0,'2023-06-27 11:19:12'),
('032022-001','01',NULL,'Inventory','Stock Out By Voucher Type (Detail)',NULL,'StockOutByVoucherTypeDetail','01','Report','',0,'2023-06-27 11:19:12'),
('032022-002','01',NULL,'Inventory','Stock In/Out Price Calender',NULL,'StockInOutPriceCalender','01','Report','',0,'2023-06-27 11:19:12'),
('052022-001','01',NULL,'','Report',NULL,'','012022-001','Menu','',10,'2023-06-27 11:19:12'),
('052022-002','01',NULL,'','G/L Listing',NULL,'','052022-001','Menu','',2,'2023-06-27 11:19:12'),
('052022-003','01',NULL,'Inventory','Sale By Sale Man (Summary)',NULL,'SaleBySaleManSummary','01','Report','',0,'2023-06-27 11:19:12'),
('052022-004','01',NULL,'Inventory','Sale By Sale Man (Detail)',NULL,'SaleBySaleManDetail','01','Report','',0,'2023-06-27 11:19:12'),
('052022-005','01',NULL,'Inventory','Sale Price Calender',NULL,'SalePriceCalender','01','Report','',0,'2023-06-27 11:19:12'),
('052022-006','01',NULL,'Inventory','Purchase Price Calender',NULL,'PurchasePriceCalender','01','Report','',0,'2023-06-27 11:19:12'),
('052022-007','01',NULL,'','Machine Property',NULL,'','50','Menu','',0,'2023-06-27 11:19:12'),
('062022-001','01',NULL,'Inventory','Stock Value',NULL,'StockValue','01','Report','',0,'2023-06-27 11:19:12'),
('062022-002','01',NULL,'','Opening Balance',NULL,'','012022-002','Menu','',0,'2023-06-27 11:19:12'),
('062022-003','01',NULL,'','Transfer',NULL,'','52','Menu','',0,'2023-06-27 11:19:12'),
('0623-001','01',NULL,'Inventory','Currency',NULL,'','50','Menu',NULL,0,'2023-06-27 11:19:12'),
('0623-002','01',NULL,'Inventory','Order',NULL,'','52','Menu',NULL,0,'2023-06-27 11:19:12'),
('0623-003','01',NULL,'Inventory','Manufacture',NULL,'','52','Menu',NULL,0,'2023-06-27 11:19:12'),
('0723-001','01',NULL,'Account','Chart Of Account',NULL,'COA','0223-010','Report',NULL,0,'2023-07-03 19:12:40'),
('0723-002','01',NULL,'Inventory','Purchase Export',NULL,'','52','Menu',NULL,0,'2023-07-07 11:04:51'),
('0723-003','01',NULL,'Inventory','Milling Entry',NULL,'','52','Menu',NULL,0,'2023-07-12 14:07:11'),
('49','01',NULL,'Inventory','Role Setting','Role Setting','','50','Menu',NULL,3,'2023-06-27 11:19:12'),
('50','01',NULL,'Inventory','System','ကုန္ပစၥည္း စာရင္း','','1','Menu',NULL,1,'2023-07-03 19:17:59'),
('52','01',NULL,'Inventory','Entry','Entry',NULL,'79','Menu',NULL,1,'2023-06-27 11:19:12'),
('54','01',NULL,'Inventory','Menu','Menu','','50','Menu',NULL,2,'2023-06-27 11:19:12'),
('56','01',NULL,'Inventory','Sale','ကုန္ေရာင္း ေဘာက္ခ်ာ','','52','Menu',NULL,1,'2023-06-27 11:19:12'),
('57','01',NULL,'Inventory','Purchase','ကုန္ဝယ္ ေဘာက္ခ်ာ','','52','Menu',NULL,2,'2023-06-27 11:19:12'),
('58','01',NULL,'Inventory','Return In','ကုန္ေရာင္း ျပန္သြင္း','','52','Menu',NULL,3,'2023-06-27 11:19:12'),
('59','01',NULL,'Inventory','Return Out','ကုန္ဝယ္ ျပန္ပို႔','','52','Menu',NULL,4,'2023-06-27 11:19:12'),
('79','01',NULL,'Inventory','Inventory','ကုန္ပစၥည္း စာရင္း','','1','Menu',NULL,2,'2023-07-03 19:18:06'),
('80','01',NULL,'Inventory','Setup','Setup',NULL,'79','Menu',NULL,3,'2023-06-27 11:19:12'),
('81','01',NULL,'Inventory','Supplier','Supplier',NULL,'80','Menu',NULL,3,'2023-06-27 11:19:12'),
('82','01',NULL,'Inventory','Customer','Customer',NULL,'80','Menu',NULL,2,'2023-06-27 11:19:12'),
('84','01',NULL,'Inventory','Other Setup','Other Setup',NULL,'80','Menu',NULL,4,'2023-06-27 11:19:12'),
('85','01',NULL,'Inventory','Stock','Stock',NULL,'80','Menu',NULL,1,'2023-06-27 11:19:12'),
('89','01',NULL,'Inventory','Stock In/Out','ကုန္ဝင္ / ကုန္ထြက္','','52','Menu',NULL,5,'2023-06-27 11:19:12'),
('95','01',NULL,'Inventory','Opening','Opening',NULL,'80','Menu',NULL,NULL,'2023-06-27 11:19:12'),
('96','01',NULL,'Inventory','System Property','System Propery','','50','Menu','',1,'2023-06-27 11:19:12'),
('97','01',NULL,'Inventory','Pattern Setup','Pattern Setup','','80','Menu',NULL,1,'2023-06-27 11:19:12'),
('99','01',NULL,'Inventory','Reorder Level','Reorder Level','','52','Menu',NULL,NULL,'2023-06-27 11:19:12'),
('rp-01','01',NULL,'Inventory','Sale By Stock (Detail)',NULL,'SaleByStockDetail','01','Report',NULL,NULL,'2023-06-27 11:19:12'),
('rp-02','01',NULL,'Inventory','Sale By Customer (Detail)',NULL,'SaleByCustomerDetail','01','Report',NULL,NULL,'2023-06-27 11:19:12'),
('rp-03','01',NULL,'Inventory','Purchase By Supplier (Detail)',NULL,'PurchaseBySupplierDetail','01','Report',NULL,NULL,'2023-06-27 11:19:12'),
('rp-04','01',NULL,'Inventory','Purchase By Stock (Detail)',NULL,'PurchaseByStockDetail','01','Report',NULL,NULL,'2023-06-27 11:19:12'),
('rp-06','01',NULL,'Inventory','Stock List By Group','Stock List By Group','StockListByGroup','01','Report',NULL,NULL,'2023-06-27 11:19:12'),
('rp-07','01',NULL,'Inventory','Top Sale By Customer','Top Sale By Customer','TopSaleByCustomer','01','Report',NULL,NULL,'2023-06-27 11:19:12'),
('rp-08','01',NULL,'Inventory','Top Sale By Sale Man','Top Sale By Sale Man','TopSaleBySaleMan','01','Report',NULL,NULL,'2023-06-27 11:19:12'),
('rp-09','01',NULL,'Inventory','Top Sale By Stock','Top Sale By Stock','TopSaleByStock','01','Report',NULL,NULL,'2023-06-27 11:19:12');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_template`
--

DROP TABLE IF EXISTS `menu_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_template` (
  `menu_id` int(15) NOT NULL,
  `bus_id` int(15) NOT NULL,
  `menu_class` varchar(150) DEFAULT NULL,
  `menu_name` varchar(50) DEFAULT NULL,
  `menu_name_mm` varchar(500) DEFAULT NULL,
  `menu_url` varchar(500) DEFAULT NULL,
  `parent_menu_id` int(11) NOT NULL,
  `menu_type` varchar(50) DEFAULT NULL,
  `account` varchar(15) DEFAULT NULL,
  `order_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`menu_id`,`bus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_template`
--

LOCK TABLES `menu_template` WRITE;
/*!40000 ALTER TABLE `menu_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilege_company`
--

DROP TABLE IF EXISTS `privilege_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege_company` (
  `role_code` varchar(15) NOT NULL,
  `comp_code` varchar(15) NOT NULL,
  `allow` bit(1) NOT NULL DEFAULT b'0',
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`role_code`,`comp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilege_company`
--

LOCK TABLES `privilege_company` WRITE;
/*!40000 ALTER TABLE `privilege_company` DISABLE KEYS */;
INSERT INTO `privilege_company` VALUES
('1','01','','2023-06-27 11:22:43');
/*!40000 ALTER TABLE `privilege_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilege_menu`
--

DROP TABLE IF EXISTS `privilege_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege_menu` (
  `menu_code` varchar(15) NOT NULL,
  `role_code` varchar(15) NOT NULL,
  `comp_code` varchar(15) NOT NULL,
  `allow` bit(1) NOT NULL DEFAULT b'0',
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`menu_code`,`role_code`,`comp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilege_menu`
--

LOCK TABLES `privilege_menu` WRITE;
/*!40000 ALTER TABLE `privilege_menu` DISABLE KEYS */;
INSERT INTO `privilege_menu` VALUES
('01','1','01','\0','2023-08-04 12:24:12'),
('012022-001','1','01','','2023-06-27 11:19:12'),
('012022-002','1','01','','2023-06-27 11:19:12'),
('012022-003','1','01','','2023-06-27 11:19:12'),
('012022-004','1','01','','2023-06-27 11:19:12'),
('012022-005','1','01','','2023-06-27 11:19:12'),
('012022-006','1','01','','2023-06-27 11:19:12'),
('012022-007','1','01','','2023-06-27 11:19:12'),
('012022-008','1','01','\0','2023-08-04 12:24:14'),
('012022-009','1','01','\0','2023-08-04 12:24:14'),
('012022-010','1','01','\0','2023-08-04 12:24:14'),
('012022-011','1','01','\0','2023-08-04 12:24:14'),
('012022-012','1','01','','2023-06-27 11:19:12'),
('012022-013','1','01','\0','2023-08-04 12:24:14'),
('012022-014','1','01','','2023-06-27 11:19:12'),
('012022-015','1','01','\0','2023-08-04 12:24:14'),
('012022-016','1','01','','2023-06-27 11:19:12'),
('022022-001','1','01','\0','2023-08-04 12:24:14'),
('0223-001','1','01','','2023-06-27 11:19:12'),
('0223-002','1','01','','2023-06-27 11:19:12'),
('0223-003','1','01','','2023-06-27 11:19:12'),
('0223-004','1','01','','2023-06-27 11:19:12'),
('0223-005','1','01','','2023-06-27 11:19:12'),
('0223-006','1','01','','2023-06-27 11:19:12'),
('0223-007','1','01','','2023-06-27 11:19:12'),
('0223-008','1','01','','2023-06-27 11:19:12'),
('0223-009','1','01','','2023-06-27 11:19:12'),
('0223-010','1','01','','2023-06-27 11:19:12'),
('0223-011','1','01','','2023-06-27 11:19:12'),
('0223-012','1','01','','2023-06-27 11:19:12'),
('0223-013','1','01','','2023-06-27 11:19:12'),
('0223-014','1','01','','2023-06-27 11:19:12'),
('0223-015','1','01','','2023-06-27 11:19:12'),
('0223-016','1','01','','2023-06-27 11:19:12'),
('0223-017','1','01','','2023-06-27 11:19:12'),
('0223-018','1','01','','2023-06-27 11:19:12'),
('0223-019','1','01','','2023-06-27 11:19:12'),
('0223-020','1','01','','2023-06-27 11:19:12'),
('0223-021','1','01','','2023-06-27 11:19:12'),
('0223-022','1','01','','2023-06-27 11:19:12'),
('032022-001','1','01','\0','2023-08-04 12:24:14'),
('032022-002','1','01','\0','2023-08-04 12:24:14'),
('052022-001','1','01','','2023-06-27 11:19:12'),
('052022-002','1','01','','2023-06-27 11:19:12'),
('052022-003','1','01','\0','2023-08-04 12:24:14'),
('052022-004','1','01','\0','2023-08-04 12:24:14'),
('052022-005','1','01','\0','2023-08-04 12:24:14'),
('052022-006','1','01','','2023-06-27 11:19:12'),
('052022-007','1','01','','2023-06-27 11:19:12'),
('062022-001','1','01','\0','2023-08-04 12:24:14'),
('062022-002','1','01','','2023-06-27 11:19:12'),
('062022-003','1','01','\0','2023-08-04 12:24:09'),
('0623-001','1','01','','2023-06-27 11:19:12'),
('0623-002','1','01','\0','2023-08-04 12:24:09'),
('0623-003','1','01','\0','2023-08-04 12:24:09'),
('0723-001','1','01','','2023-07-03 19:11:59'),
('0723-002','1','01','\0','2023-08-04 12:24:09'),
('0723-003','1','01','\0','2023-08-04 12:24:09'),
('49','1','01','','2023-06-27 11:19:12'),
('50','1','01','','2023-06-27 11:19:12'),
('52','1','01','\0','2023-08-04 12:24:09'),
('53','1','01','','2023-06-27 11:19:12'),
('54','1','01','','2023-06-27 11:19:12'),
('56','1','01','\0','2023-08-04 12:24:09'),
('57','1','01','\0','2023-08-04 12:24:09'),
('58','1','01','\0','2023-08-04 12:24:09'),
('59','1','01','\0','2023-08-04 12:24:12'),
('65','1','01','','2023-06-27 11:19:12'),
('66','1','01','','2023-06-27 11:19:12'),
('79','1','01','\0','2023-08-04 12:24:14'),
('80','1','01','\0','2023-08-04 12:24:12'),
('81','1','01','\0','2023-08-04 12:24:12'),
('82','1','01','\0','2023-08-04 12:24:12'),
('84','1','01','\0','2023-08-04 12:24:12'),
('85','1','01','\0','2023-08-04 12:24:12'),
('89','1','01','\0','2023-08-04 12:24:12'),
('95','1','01','\0','2023-08-04 12:24:12'),
('96','1','01','','2023-06-27 11:19:12'),
('97','1','01','\0','2023-08-04 12:24:12'),
('99','1','01','\0','2023-08-04 12:24:09'),
('rp-01','1','01','\0','2023-08-04 12:24:14'),
('rp-02','1','01','\0','2023-08-04 12:24:14'),
('rp-03','1','01','\0','2023-08-04 12:24:14'),
('rp-04','1','01','\0','2023-08-04 12:24:14'),
('rp-05','1','01','','2023-06-27 11:19:12'),
('rp-06','1','01','\0','2023-08-04 12:24:14'),
('rp-07','1','01','\0','2023-08-04 12:24:14'),
('rp-08','1','01','\0','2023-08-04 12:24:14'),
('rp-09','1','01','\0','2023-08-04 12:24:14'),
('rp-10','1','01','','2023-06-27 11:19:12');
/*!40000 ALTER TABLE `privilege_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `project_no` varchar(15) NOT NULL,
  `comp_code` varchar(15) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `budget` double DEFAULT NULL,
  `project_status` varchar(15) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`project_no`,`comp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_code` varchar(15) NOT NULL,
  `role_name` varchar(255) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`role_code`,`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES
('1','Admin','2023-06-12 08:15:38');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_prop`
--

DROP TABLE IF EXISTS `role_prop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_prop` (
  `role_code` varchar(15) NOT NULL,
  `prop_key` varchar(50) NOT NULL,
  `comp_code` varchar(15) NOT NULL,
  `remark` varchar(15) DEFAULT NULL,
  `prop_value` varchar(255) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`role_code`,`prop_key`,`comp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_prop`
--

LOCK TABLES `role_prop` WRITE;
/*!40000 ALTER TABLE `role_prop` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_prop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seq_table`
--

DROP TABLE IF EXISTS `seq_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seq_table` (
  `seq_no` int(11) NOT NULL,
  `option` varchar(15) NOT NULL,
  `period` varchar(15) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`seq_no`,`period`,`option`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seq_table`
--

LOCK TABLES `seq_table` WRITE;
/*!40000 ALTER TABLE `seq_table` DISABLE KEYS */;
INSERT INTO `seq_table` VALUES
(3,'Menu','0723','2023-07-12 14:07:11');
/*!40000 ALTER TABLE `seq_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_prop`
--

DROP TABLE IF EXISTS `sys_prop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_prop` (
  `prop_key` varchar(255) NOT NULL,
  `prop_value` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `comp_code` varchar(15) NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`prop_key`,`comp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_prop`
--

LOCK TABLES `sys_prop` WRITE;
/*!40000 ALTER TABLE `sys_prop` DISABLE KEYS */;
INSERT INTO `sys_prop` VALUES
('bank.group','601',NULL,'01','2023-06-27 18:00:32'),
('capital.account','02',NULL,'01','2023-06-27 18:00:32'),
('cash.group','600',NULL,'01','2023-06-27 18:00:32'),
('check.sale.A4','false',NULL,'01','2023-06-27 18:00:43'),
('check.sale.A5','1',NULL,'01','2023-06-27 15:39:59'),
('check.sale.voucher','true',NULL,'01','2023-06-27 18:00:44'),
('creditor.account','300001',NULL,'01','2023-06-27 18:00:32'),
('creditor.group','300',NULL,'01','2023-06-27 18:00:32'),
('current.account','06',NULL,'01','2023-06-27 18:00:32'),
('customer.account','D-00041',NULL,'01','2023-06-27 15:39:59'),
('debtor.account','604001',NULL,'01','2023-06-27 18:00:32'),
('debtor.group','604',NULL,'01','2023-06-27 18:00:32'),
('default.currency','MMK',NULL,'01','2023-06-27 15:39:59'),
('default.department','01',NULL,'01','2023-06-27 19:36:01'),
('default.location','001-0001',NULL,'01','2023-07-12 14:09:15'),
('disable.calculate.sale.stock','false',NULL,'01','2023-06-27 15:39:59'),
('disable.department','false',NULL,'01','2023-06-27 15:39:59'),
('expense.account','05',NULL,'01','2023-06-27 18:00:32'),
('fixed.account','01',NULL,'01','2023-06-27 18:00:32'),
('income.account','04',NULL,'01','2023-06-27 18:00:32'),
('inventory.group','602',NULL,'01','2023-06-27 18:00:32'),
('liability.account','03',NULL,'01','2023-06-27 18:00:32'),
('otherincome.account','08',NULL,'01','2023-06-27 18:00:32'),
('printer.name','Canon LBP3010/LBP3018/LBP3050(2)',NULL,'01','2023-06-27 15:39:59'),
('printer.print','1',NULL,'01','2023-06-27 15:39:59'),
('purchase.account','07',NULL,'01','2023-06-27 18:00:32'),
('purchase.batch.detail','false',NULL,'01','2023-06-27 15:39:59'),
('purchase.show.expense','false',NULL,'01','2023-06-27 15:39:59'),
('purchase.show.grn','false',NULL,'01','2023-06-27 15:39:59'),
('purchase.voucher.edit','false',NULL,'01','2023-06-27 15:39:59'),
('report.path','C:\\CoreValue\\services\\core-inventory\\font\\Zawgyi-One.ttf',NULL,'01','2023-06-27 15:39:59'),
('report.purchase.voucher','PurchaseVoucher(KPS)',NULL,'01','2023-06-27 15:39:59'),
('report.sale.A4','SaleVoucherA4',NULL,'01','2023-06-27 15:39:59'),
('report.sale.A5','SaleVoucherA5(KPS)',NULL,'01','2023-06-27 15:39:59'),
('report.sale.voucher','SaleVoucherPrinter',NULL,'01','2023-06-27 15:39:59'),
('sale.voucher.edit','true',NULL,'01','2023-06-27 18:21:41'),
('stock.use.weight','false',NULL,'01','2023-06-27 18:21:29'),
('supplier.account','D-00056',NULL,'01','2023-06-27 15:39:59'),
('trader.balance','0',NULL,'01','2023-06-27 15:39:59');
/*!40000 ALTER TABLE `sys_prop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `mac_id` int(11) NOT NULL,
  `expired` bit(1) NOT NULL,
  `revoked` bit(1) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `token_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`mac_id`),
  UNIQUE KEY `UK_pddrhgwxnms2aceeku9s2ewy5` (`token`),
  KEY `FKiblu4cjwvyntq3ugo31klp1c6` (`mac_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
INSERT INTO `token` VALUES
(2,'\0','\0','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJSS1ExLjIwMDgyNi4wMDIiLCJhdXRoIjoiUk9MRV9VU0VSIiwiaWF0IjoxNjg3ODY1MjY1LCJleHAiOjE2OTA0NTcyNjV9.A0xJWnH_G96YuIS1pPBJvbkKo0kOxGcekglceS41PpM','BEARER'),
(3,'\0','\0','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJMMUhGOUI4MEJKViIsImF1dGgiOiJST0xFX1VTRVIiLCJpYXQiOjE2ODc4NzQ0MTMsImV4cCI6MTY5MDQ2NjQxM30.oOPk9bbTKp_0PtKnuxYGY9OUx70_xlyb17bvoAGkXfc','BEARER'),
(39,'\0','\0','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJQR1dIVDAwV0JDNlVMQyIsImF1dGgiOiJST0xFX1VTRVIiLCJpYXQiOjE2ODc1MTY4MjIsImV4cCI6MTY5MDEwODgyMn0.tH4jE2Nk25n0-K-fszScnfILvYgtME8M0G4P4oaeS8U','BEARER');
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-12 18:25:50
